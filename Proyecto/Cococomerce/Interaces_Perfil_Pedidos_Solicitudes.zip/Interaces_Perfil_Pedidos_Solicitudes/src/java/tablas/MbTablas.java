/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablas;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import tablas.modelo.Datos;

/**
 *
 * @author Christian
 */
@Named(value = "mbTablas")
@SessionScoped
public class MbTablas implements Serializable {

    private ArrayList<Datos> lst = null;

    public ArrayList<Datos> getLst() {
        if(lst == null){
            lst = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                Datos d = new Datos ();
                d.setUsuario("Usuario"+i);
                d.setPedido("Pedido"+i);
                d.setFecha("19/11/2017");
                lst.add(d);
            }
        }
        
        return lst;
    }

    public void setLst(ArrayList<Datos> lst) {
        this.lst = lst;
    }
    
    
    
    public MbTablas() {
    }
    
}
