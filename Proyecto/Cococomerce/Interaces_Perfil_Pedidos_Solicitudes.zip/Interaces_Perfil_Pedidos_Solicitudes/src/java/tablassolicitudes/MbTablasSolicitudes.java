/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablassolicitudes;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import tablassolicitudes.mod.DatosSolicitudes;

/**
 *
 * @author Christian
 */
@Named(value = "mbTablasSolicitudes")
@SessionScoped
public class MbTablasSolicitudes implements Serializable {

    private ArrayList<DatosSolicitudes> list = null;
    
    public MbTablasSolicitudes() {
        
        
        
    }

    public ArrayList<DatosSolicitudes> getList() {
        if (list == null){
            list = new ArrayList();
            for (int i = 0; i < 10; i++){
                DatosSolicitudes e = new DatosSolicitudes();
                e.setUsuario("Usuario"+i);
                e.setPedido("Pedido"+i);
                e.setFecha("19/11/2017");
                e.setCampo4("Entrega"+i);
                list.add(e);
            }
        }
        return list;
    }

    public void setList(ArrayList<DatosSolicitudes> list) {
        this.list = list;
    }
    
}
